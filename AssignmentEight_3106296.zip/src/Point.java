// Phuong Nghi Nguyen - 3106296
public class Point {
    private int x;
    private int y;

    // Constructor to initialize a Point with specified x and y coordinates
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getter and setter method for the x coordinate
    public int getX() {
        return x;
    }
    public void setX(int x) {
        this.x = x;
    }

    // Getter and setter method for the y coordinate
    public int getY() {
        return y;
    }
    public void setY(int y) {
        this.y = y;
    }

    // Override toString method to display the coordinates of the Point
    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    // Override hashCode method to generate a hash code for Point objects
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + x;
        result = prime * result + y;
        return result;
    }

    // Override equals method to compare two Point objects for equality
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Point other = (Point) obj;
        if (x != other.x)
            return false;
        if (y != other.y)
            return false;
        return true;
    }
}
