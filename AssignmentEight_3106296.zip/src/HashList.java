// Phuong Nghi Nguyen - 3106296
import java.util.LinkedList;
import java.util.Random;

public class HashList<E> {
    private LinkedList<E> data[];

    // Constructor to initialize the HashList with a specified number of buckets
    public HashList(int n) {
        // Creating an array of LinkedLists to store the elements
        data = (LinkedList<E>[]) (new LinkedList[n]);
        // Initializing each LinkedList in the array
        for (int j = 0; j < data.length; j++)
            data[j] = new LinkedList<E>();
    }

    // Method to calculate the hash code for an element
    private int hashC(E x) {
        int k = x.hashCode();
        // Calculating the hash code and ensuring it's non-negative
        int h = Math.abs(k % data.length);
        return (h);
    }

    // Method to add an element to the HashList
    public void add(E x) {
        // Getting the index of the bucket using the hash code
        int index = hashC(x);
        // Adding the element to the corresponding bucket
        data[index].add(x);
    }

    // Method to check if an element is present in the HashList
    public boolean contains(E x) {
        // Getting the index of the bucket using the hash code
        int index = hashC(x);
        // Checking if the element is present in the corresponding bucket
        return data[index].contains(x);
    }

    // Method to remove an element from the HashList
    public boolean remove(E x) {
        // Getting the index of the bucket using the hash code
        int index = hashC(x);
        // Removing the element from the corresponding bucket
        return data[index].remove(x);
    }

    // Method to display the elements in each bucket of the HashList
    public void displayLists() {
        // Iterating through each bucket
        for (int i = 0; i < data.length; i++) {
            // Printing the elements in the current bucket
            System.out.println("Bucket " + i + ": " + data[i]);
        }
    }

    // Method to calculate the percentage of buckets used in the HashList
    public double percentUsed() {
        int usedBuckets = 0;
        // Counting the number of non-empty buckets
        for (int i = 0; i < data.length; i++) {
            if (!data[i].isEmpty()) {
                usedBuckets++;
            }
        }
        // Calculating and returning the percentage of buckets used
        return ((double) usedBuckets / data.length) * 100;
    }

    public static void main(String[] args) {
        // Creating an instance of HashList<Point> with 1000 buckets
        HashList<Point> hashList = new HashList<>(1000);

        // Generating 1000 random Point instances with values from 0 to 1000
        Random random = new Random();
        for (int i = 0; i < 1000; i++) {
            int x = random.nextInt(1001); // 0 to 1000 inclusive
            int y = random.nextInt(1001); // 0 to 1000 inclusive
            // Creating a new Point instance
            Point point = new Point(x, y);
            // Adding the Point instance to the HashList
            hashList.add(point);
        }

        // Printing the percentage of buckets used
        System.out.println("Percentage of buckets used: " + hashList.percentUsed() + "%");

        // Displaying the elements in each bucket
        hashList.displayLists();
    }
}
