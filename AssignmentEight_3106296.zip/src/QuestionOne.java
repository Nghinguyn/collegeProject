// Phuong Nghi Nguyen - 3106296
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public class QuestionOne {

    // Method to filter names based on a predicate
    public static ArrayList<String> filterNames(Predicate<String> predicate, ArrayList<String> names) {
        // Create a new ArrayList to store the filtered names
        ArrayList<String> filteredNames = new ArrayList<>();
        // Iterate through each name in the provided list
        for (String name : names) {
            // Check if the name satisfies the predicate
            if (predicate.test(name)) {
                // If it does, add it to the filtered list
                filteredNames.add(name);
            }
        }
        // Return the filtered list of names
        return filteredNames;
    }

    public static void main(String[] args) {
        // Sample list of names
        ArrayList<String> strings = new ArrayList<>();
        strings.add("John");
        strings.add("123abc");
        strings.add("_Alice");
        strings.add("too_long_name");

        // Predicate lambda function to filter names that start with a letter or underscore
        Predicate<String> startsWithLetterOrUnderscore = s -> s.matches("[a-zA-Z_].*");
        // Predicate lambda function to filter names that have less than 10 characters
        Predicate<String> lessThan10Characters = s -> s.length() < 10;

        // Create a new ArrayList to store the filtered strings
        ArrayList<String> filteredStrings = new ArrayList<>();

        // Loop through each string in the ArrayList
        for(String string : strings) {
            // Check if the string satisfies both predicates
            if (startsWithLetterOrUnderscore.test(string) && lessThan10Characters.test(string)) {
                // If it does, add it to the filtered list
                filteredStrings.add(string);
            }
        }

        // Print the filtered strings
        System.out.println("Filtered strings: " + filteredStrings);

        // UnaryOperator lambda function to add an underscore if the name doesn't start with a letter or underscore
        UnaryOperator<String> addUnderscoreIfNotStartsWithLetterOrUnderscore = s -> {
            if (!s.matches("[a-zA-Z_].*")) {
                return "_" + s;
            }
            return s;
        };

        // UnaryOperator lambda function to reduce the size of names to 10 characters or less
        UnaryOperator<String> reduceSizeTo10 = s -> s.length() > 10 ? s.substring(0, 10) : s;

        // Cleaning names by adding underscores and reducing the size using the defined UnaryOperators
        cleanNames(addUnderscoreIfNotStartsWithLetterOrUnderscore, strings);
        cleanNames(reduceSizeTo10, strings);

        // Printing the cleaned names
        System.out.println("Cleaned names: " + strings);
    }

    // Method to clean names based on a UnaryOperator
    public static void cleanNames(UnaryOperator<String> operator, ArrayList<String> names) {
        // Iterate through each name in the provided list
        for (int i = 0; i < names.size(); i++) {
            // Apply the UnaryOperator to each name and replace it in the list
            names.set(i, operator.apply(names.get(i)));
        }
    }

}