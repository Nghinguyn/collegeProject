// Phuong Nghi Nguyen - 3106296
import java.util.Iterator;
import java.util.NoSuchElementException;

// create StackArray class that implements Stack and Iterable abstract classes
class StackArray<E> implements Stack<E>, Iterator<E> {
    private Object[] array;
    private int top;
    private int capacity;
    // Constructor to initialize the stack with the given capacity
    public StackArray(int capacity) {
        // Set the capacity of the stack
        this.capacity = capacity;
        // Create a new array to hold the elements of the stack
        array = new Object[capacity];
        // Set the top index to -1 to indicate an empty stack
        top = -1;
    }
    // Method to push an element onto the stack
    @Override
    public boolean push(E x) {
        // Check if the stack is full
        if (isFull())
            return false;
        // Increment the top index and add the element to the stack
        array[++top] = x;
        // Return true to indicate successful push
        return true;
    }
    // Method to pop an element from the stack
    @Override
    public E pop() {
        // Check if the stack is empty
        if (isEmpty())
            // Throw NoSuchElementException if the stack is empty
            throw new NoSuchElementException("Stack underflow");
        // Return and remove the element at the top of the stack
        return (E) array[top--];
    }
    // Method to return the element at the top of the stack without removing it
    @Override
    public E peek() {
        // Check if the stack is empty
        if (isEmpty())
            // Throw NoSuchElementException if the stack is empty
            throw new NoSuchElementException("Stack is empty");
        // Return the element at the top of the stack
        return (E) array[top];
    }
    // Method to check if the stack is empty
    @Override
    public boolean isEmpty() {
        // Return true if the top index is -1 (indicating an empty stack)
        return top == -1;
    }
    // Method to check if the stack is full
    @Override
    public boolean isFull() {
        // Return true if the top index is equal to the capacity minus 1 (indicating a full stack)
        return top == capacity - 1;
    }
    // Method to display the elements of the stack
    @Override
    public void display() {
        // Print "Stack: " as a prefix for the stack elements
        System.out.print("Stack: ");
        // Iterate over the elements of the stack from top to bottom
        for (int i = top; i >= 0; i--) {
            // Print each element followed by a space
            System.out.print(array[i] + " ");
        }
        // Print a new line to separate the output
        System.out.println();
    }
    // Initialize the currentIndex to -1 to prepare for iteration
    private int currentIndex = -1;

    // Override the hasNext() method required by the Iterator interface
    @Override
    public boolean hasNext() {
        // Check if there are more elements to iterate over
        return currentIndex < top;
    }

    // Override the next() method required by the Iterator interface
    @Override
    public E next() {
        // Check if there are more elements to iterate over
        if (!hasNext()) {
            // If there are no more elements, throw NoSuchElementException
            throw new NoSuchElementException();
        }
        // Return the next element in the iteration and move the cursor to the next position
        return (E) array[++currentIndex];
    }
}
