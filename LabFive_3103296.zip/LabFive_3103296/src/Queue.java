interface Queue<E>{
    public boolean enqueue(E x);
    public E dequeue();
    public E peek();
    public boolean isEmpty();
    public boolean isFull();
    public void display();
    public boolean contains(E x);
}
