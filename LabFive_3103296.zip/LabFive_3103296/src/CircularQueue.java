import java.util.LinkedList;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class CircularQueue<E> implements Queue<E>, Iterator<E> {
    // Declare a private LinkedList to hold the elements of the queue
    private LinkedList<E> queue;
    // Declare a private variable to store the maximum size of the queue
    private int maxSize;
    // Declare a private variable to keep track of the current index for iteration
    private int index;

    // Constructor to initialize the CircularQueue with the given maximum size
    public CircularQueue(int maxSize) {
        // Assign the maximum size to the maxSize variable
        this.maxSize = maxSize;
        // Create a new LinkedList to serve as the underlying data structure for the queue
        this.queue = new LinkedList<>();
        // Initialize the index to 0
        this.index = 0;
    }

    // Method to enqueue an element into the queue
    @Override
    public boolean enqueue(E x) {
        // Check if the queue is full
        if (isFull()) {
            return false; // If full, return false to indicate failure
        }
        // Add the element to the end of the queue
        queue.addLast(x);
        return true; // Return true to indicate successful enqueue
    }

    // Method to dequeue an element from the queue
    @Override
    public E dequeue() {
        // Check if the queue is empty
        if (isEmpty()) {
            return null; // If empty, return null to indicate failure
        }
        // Remove and return the first element from the queue
        return queue.removeFirst();
    }

    // Method to peek at the first element of the queue without removing it
    @Override
    public E peek() {
        // Check if the queue is empty
        if (isEmpty()) {
            return null; // If empty, return null
        }
        // Return the first element of the queue
        return queue.getFirst();
    }

    // Method to check if the queue is empty
    @Override
    public boolean isEmpty() {
        // Check if the queue is empty using the isEmpty() method of LinkedList
        return queue.isEmpty();
    }

    // Method to check if the queue is full
    @Override
    public boolean isFull() {
        // Check if the size of the queue is equal to the maximum size
        return queue.size() == maxSize;
    }

    // Method to display the elements of the queue
    @Override
    public void display() {
        // Print "Queue: " as a prefix for the queue elements
        System.out.print("Queue: ");
        // Iterate over the elements of the queue and print each element followed by a space
        for (E element : queue) {
            System.out.print(element + " ");
        }
        // Print a new line to separate the output
        System.out.println();
    }

    // Method to check if the queue contains a specific element
    @Override
    public boolean contains(E x) {
        // Use the contains() method of LinkedList to check if the queue contains the element
        return queue.contains(x);
    }

    // Method to check if there are more elements to iterate over
    @Override
    public boolean hasNext() {
        // Return true if the queue is not empty
        return !isEmpty();
    }

    // Method to get the next element in the iteration
    @Override
    public E next() {
        // Check if there are more elements to iterate over
        if (!hasNext()) {
            // If no more elements, throw NoSuchElementException
            throw new NoSuchElementException();
        }
        // Get the element at the current index and update the index for the next iteration
        E element = queue.get(index);
        index = (index + 1) % queue.size();
        return element; // Return the retrieved element
    }
}