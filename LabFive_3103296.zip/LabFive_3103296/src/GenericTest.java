// Phuong Nghi Nguyen - 3106296
import java.util.Iterator;
public class GenericTest {
    public static void main(String[] args) {

        // TEST StackArray METHODS
        StackArray<Integer> stack = new StackArray<>(5);
        // Test push method
        stack.push(9); // Should add 9 to the stack
        stack.push(4); // Should add 4 to the stack
        stack.push(6); // Should add 6 to the stack
        stack.push(8); // Should add 8 to the stack
        stack.push(2); // Should add 2 to the stack

        // Test display method
        stack.display(); // Should print "Stack: 2 8 6 4 9 "

        // Test pop method
        int poppedElement1 = stack.pop(); // Should pop the last element being added into the stack: 2
        int poppedElement2 = stack.pop(); // Should pop the next last element being added into the stack: 8
        // Should print "Popped element: 2 8"
        System.out.println("Popped element: " + poppedElement1 + " " + poppedElement2);

        // Test peek method
        int topElement = stack.peek(); // should assign 6 to topElement instance
        // Should print "Top element: 6"
        System.out.println("Top element: " + topElement);

        // print something to separate test methods from question 1 and 2
        System.out.println("____________________________________\n CirularQueue's class method:"
        + "\n____________________________________");

        // TEST QUESTION 2 METHOD

        // Set the maximum size as 5
        CircularQueue queue = new CircularQueue<>(5);

        // test isEmpty method
        System.out.println("Is queue empty? " + queue.isEmpty()); // Should print true

        // test isFull method
        System.out.println("Is queue full? " + queue.isFull()); // Should print false

        // test enqueue method
        // add 4 to the queue using enqueue method
        queue.enqueue(4);
        // add 2 to the queue using enqueue method
        queue.enqueue(2);
        // add 7 to the queue using enqueue method
        queue.enqueue(7);
        // add 12 to the queue using enqueue method
        queue.enqueue(12);
        // add 85 to the queue using enqueue method
        queue.enqueue(85);

        // test isFull method again
        System.out.println("Is queue full? " + queue.isFull()); // Should print true

        // test display method
        queue.display(); // Should print "Queue: 4 2 7 12 85 "

        // test dequeue method
        System.out.println("Dequeuing: " + queue.dequeue()); // Should print 4
        System.out.println("Queue elements after dequeue: ");
        queue.display(); // Should print "Queue: 2 7 12 85 "

        // test contains method
        System.out.println("Is 3 present in the queue? " + queue.contains(3)); // Should print false
        System.out.println("Is 7 present in the queue? " + queue.contains(7)); // Should print true

        // test peek method
        System.out.println("Peek: " + queue.peek()); // Should print 2
    }
}
