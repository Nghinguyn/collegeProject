// Interface class
interface Stack<E> {
    boolean push(E x);
    E pop();
    E peek();
    boolean isEmpty();
    boolean isFull();
    void display();
}