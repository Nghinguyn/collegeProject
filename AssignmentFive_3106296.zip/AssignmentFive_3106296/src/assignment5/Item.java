package assignment5;

public class Item {
	
		private String name;
		private double weight;
		
		
		
		public Item(String name, double weight) {
			//setter = this.(variable's name)
			//getter = return + (variable's name)
			this.name = name;
			this.weight = weight;	
		}
		//make a getter to return the item's weight 
		public double getWeight() {
			return weight;
		}
		
		//make a getter to return the item's name 
		public String getName() {
			return name;
		}
		
		
}
