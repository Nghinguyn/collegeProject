package assignment5;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {

	// Task 1

	/*
	 * Create a method to modify the array list
	 */
	public static void textEditor(ArrayList<String> sentenceArrayList) {

		// Make a loop to print out the original texts before editing it
		System.out.println("Original text:");
		for (int i = 0; i < sentenceArrayList.size(); i++) {
			String originalText = sentenceArrayList.get(i);
			System.out.println(originalText);
		}

		// Print this out before starting modify it with the for loop to avoid repeating
		System.out.println("\nEdited text:");
		/*
		 * To remove excess whitespace Create a loop that loop through all string in the
		 * array list
		 */
		for (int i = 0; i < sentenceArrayList.size(); i++) {
			// Get each string in the list to work with
			String sentence = sentenceArrayList.get(i);
			// Trim down the string white space
			sentence = sentence.trim();
			// Add white space between each word together
			sentence = sentence.replaceAll("\\s+", " ");
			/*
			 * To make the first letter upper case Create 2 substrings for the first letter
			 * and the remaining letters firstLetter substring contains the first letter of
			 * the string remainingLetters substring contains the remainder
			 */
			String firstLetter = sentence.substring(0, 1);
			String remainingLetters = sentence.substring(1, sentence.length());
			// use toUpperCase() function to change first letter into upper case letter
			firstLetter = firstLetter.toUpperCase();
			// Combine the two substring together
			sentence = firstLetter + remainingLetters;
			/*
			 * 
			 */
			char lastLetter = sentence.charAt(sentence.length() - 1);
			if (lastLetter == '.' || lastLetter == '!' || lastLetter == '?') {
				System.out.println(sentence);
			} else {
				String punctuation = ".";
				System.out.println(sentence + punctuation);
			}
		}
	}

	public static void main(String[] args) {

		ArrayList<String> sentenceArrayList = new ArrayList<String>();
		sentenceArrayList.add("every   day has potentials     and risks");
		sentenceArrayList.add("  be with people that make you feel better.");
		sentenceArrayList.add("be kind   to yourself");
		sentenceArrayList.add("   When you're    standing outside then    you're outstanding!");

		textEditor(sentenceArrayList);
		System.out.println();

		// Task 2

		Circle circle1 = new Circle(3, "red");
		Circle circle2 = new Circle(9, "yellow");
		Circle circle3 = new Circle(6, "turquoise ");

		double area1 = circle1.area(circle1.radius);
		double area2 = circle2.area(circle2.radius);
		double area3 = circle3.area(circle3.radius);

		/*
		 * Now we check the area and put them in order as this is not really a list but
		 * separated variables, it is quite difficult to create a for loop and there're
		 * only 3 circles, so I check each case using if statement. 3 circles will have
		 * 3! = 6 cases: (1-2-3, 1-3-2, 2-1-3, 2-3-1, 3-1-2, 3-2-1). Compare it using
		 * if.
		 */

		if (area1 < area2 && area2 < area3) {

			System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the largest area");
			System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the second largest area");
			System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the smallest area");

		}

		if (area1 < area2 && area2 > area3) {
			// The previous "area1 < area2 && area2 > area3" do not give clear information
			// of the circles' order, we still need to compare the other 2 circles
			// So there will be 2 possible cases
			if (area1 <= area3) {

				System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the largest area");
				System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the second largest area");
				System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the smallest area");
			}
			if (area1 >= area3) {

				System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the largest area");
				System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the second largest area");
				System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the smallest area");

			}
		}
		if (area1 > area2 && area2 > area3) {

			System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the largest area");
			System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the second largest area");
			System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the smallest area");

		}
		if (area1 > area2 && area2 < area3) {
			// The previous "area1 < area2 && area2 > area3" do not give clear information
			// of the circles' order, we still need to compare the other 2 circles
			// So there will be 2 possible cases
			if (area1 < area3) {

				System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the largest area");
				System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the second largest area");
				System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the smallest area");
			}
			if (area1 > area3) {

				System.out.println("The " + circle1.getColour(circle1.colour) + " circle has the largest area");
				System.out.println("The " + circle3.getColour(circle3.colour) + " circle has the second largest area");
				System.out.println("The " + circle2.getColour(circle2.colour) + " circle has the smallest area");
			}
		}
		//Since task 3 is very long, I separated it into another java file called "Test1.java"
	}
}
