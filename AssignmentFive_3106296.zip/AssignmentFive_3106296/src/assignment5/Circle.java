package assignment5;
import java.math.*;
public class Circle {

		//Declare
		double radius;
		String colour;
		
		//Create the constructor
		public Circle(double radius, String colour) {
			this.radius = radius;
			this.colour = colour;
			}
		
		//Create method to calculate the circle's area (area = r^2 * pi) 
		public double area( double radius) {
			double circleArea = radius*radius * Math.PI;
			//return the result
			return circleArea;
		}
		
		//Create method to get the colour
		public String getColour(String colour) {
			//return colour's value
			return colour;
		}
		
}
