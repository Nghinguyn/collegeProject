package assignment5;

import java.util.ArrayList;
import java.util.Scanner;

public class Test1 {

	// Create an ArrayList of Items, so the data type for the array will be assigned
	// as the Item value
	public static ArrayList<Item> inventory = new ArrayList<Item>();
	// Declare the maximum weight outside of the main class
	public static final double MAX_WEIGHT = 100;

	public static void main(String[] args) {
		// Create a scanner
		Scanner scanner1 = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);

		boolean loop = true;
		System.out.println(
				"Choose an option \n  Add: Add a new Item to Inventory \n  Drop: Remove an Item from Inventory \n  Show: See Inventory \n  Quit: Leave menu");
		// Create a while loop that loop until the user type "quit" to exit the loop
		while (loop) {
			// Take in the user's choice
			String option = scanner1.nextLine();
			// Trim down excess white spaces in case user type in any white spaces
			option = option.trim();

			if (option.equalsIgnoreCase("add")) {
				System.out.println("Enter item's name and weight");
				// Take the input's value
				String userInput = scanner2.nextLine();

				// split the string input into 2 so that we can take the item's name and item's
				// weight
				String[] inputString = userInput.split(" ");

				// item name will be the first word
				String itemName = inputString[0];
				// item weight will be the second, the original data type is String so we need
				// to press it into double type
				double itemWeight = Double.parseDouble(inputString[1]);
				// after initializing the new variable into the array list
				Item item = new Item(itemName, itemWeight);

				/*
				 * We need to add the item into the array list first, so that we can calculate
				 * the total sum first, then set the condition to remove it if it's exceed max
				 * weight. If we do not add the item in first, the total weight of the array
				 * list won't change because the item hasn't been added to the inventory
				 */
				addItem(item);
				// Check if the inventory value has passed maximum weight
				double currentWeight = calculateWeight();
				if (currentWeight < MAX_WEIGHT) {

					// print out the notification for user
					System.out.println("Added " + item.getName() + " into the inventory, the current weight is "
							+ currentWeight + "/100");
					continue;
				} else {
					System.out.println("Reached inventory's maximum capacity, cannot add more");
					// Remove the item because it exceed max weight
					inventory.remove(item);
					continue;
				}
			}

			if (option.equalsIgnoreCase("drop")) {
				System.out.println("Enter a name");
				String userInput = scanner2.nextLine();
				// Trim down excess white spaces in case user type in any white spaces
				userInput = userInput.trim();
				// create the for loop to find the matching item's that the use want to drop
				for (int i = 0; i < inventory.size(); i++) {
					if (userInput.equalsIgnoreCase(inventory.get(i).getName())) {
						System.out.print("Removed " + inventory.get(i).getName() + " from the inventory. ");
						// remove the item from the array list so the the total weight get to be updated
						inventory.remove(inventory.get(i));
						// print out the rest of the notification
						System.out.println("The current weight is: " + calculateWeight() + "/100");
						// Now that we have found and removed the needed item, break the for loop
						break;
					}
					/*
					 * if all the inventory item does not match, break the searching for loop and
					 * print out that the item does not exist in the inventory
					 */
					else {
						// Then continue the outer if("drop") case to reach to the notification that the
						// input item name is not found
						continue;
					}
				}
				// Print out not found notification
				System.out.println(userInput + " does not exist in the inventory");
				// continue the program
				continue;
			}

			if (option.equalsIgnoreCase("show")) {
				System.out.println("Item	:	Weight");
				for (int i = 0; i < inventory.size(); i++) {
					System.out.println(inventory.get(i).getName() + "	:	" + inventory.get(i).getWeight());
				}
				continue;
			}

			if (option.equalsIgnoreCase("quit")) {
				/*
				 * if the user does not want to modify the inventory anymore, print out a
				 * notification to let the user know they have exit the program, use "break" to
				 * break the loop.
				 */
				System.out.print("Exit the program successfully");
				break;
			}
			else {
				/*
				 * Print out a notification for user to choose an option in case the user hasn't
				 * chose the option. A way to catch some exceptions or to prevent program crash
				 */
				System.out.println("Choose an option(add/drop/show/quit) first");
				continue;
			}
		}
	}

	// METHOD to add a new item into the inventory
	public static Item addItem(Item item) {
		// use regular .add(object) method to add the item in
		inventory.add(item);
		return item;
	}

	// METHOD to calculate the total weight of items in the array list
	public static double calculateWeight() {
		// Create a variable to store the total number and initialize it
		double totalWeight = 0;
		// Create a for loop to get the sum of the array list
		for (int i = 0; i < inventory.size(); i++) {
			totalWeight += inventory.get(i).getWeight();
		}
		// return the total weight
		return totalWeight;
	}
}
